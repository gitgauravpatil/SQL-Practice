
/*
10. Create a stored procedure that creates a list of customers that have a rental_id,
but no payment_id i.e. those customers who have not paid.
Store the names of customers who have not paid to a table named 'DelayedPayment'.
Store the names of customers and the payment amount who have paid to a table named 'OntimePayment'.*/

DELIMITER %%
CREATE PROCEDURE cust()
BEGIN
CREATE table delay_payment as 
SELECT * FROM payment p join customer c on p.customer_id = c.customer_id
where p.rental_id is not null and p.payment_id is null;

CREATE TABLE ontime_payment AS
select distinct c.*
FROM payment p join customer c on p.customer_id = c.customer_id
where p.rental_id is not null and p.payment_id is not null;

END %%

call cust
select * from  delay_payment;
drop procedure cust;