/*
1. Create SP to insert Customer Data if not exists.
 Customer existence should be based on mobile no. Returns customer id (auto-generated).
 */
 
 DELIMITER //
 CREATE PROCEDURE check_customer(c_name VARCHAR(20),c_address VARCHAR(20),c_no BIGINT)
BEGIN
	INSERT INTO Customer(Customer_name,Customer_City,Customer_no)
    SELECT * FROM (SELECT c_name,c_address,c_no) AS demo_c
    WHERE NOT EXISTS(SELECT Customer_no FROM Customer WHERE Customer_no = c_no);
	SELECT Customer_id,Customer_name FROM Customer WHERE Customer_no = c_no ORDER BY Customer_id DESC LIMIT 1;
END //

DROP PROCEDURE check_customer;
CALL check_customer("Chinar s",'ppne',9876543219);




/*
2.Create a function to return Bill No to be used. BIL/YYYYMMDD/xxxx (where xxxx is 0001 to 9999).
*/

DELIMITER //
CREATE FUNCTION get_bill_no(ddate DATE)
RETURNS VARCHAR(25)  
DETERMINISTIC
BEGIN
	DECLARE padding int;
	DECLARE Bill_view VARCHAR(30);
	IF ddate IS null
	THEN
     return 'Please Enter the valid Date';
     ELSE
		SET padding = (SELECT count(Bill_id) FROM Bill WHERE Bill_date = ddate);
		SELECT concat('BIL/',date_format(ddate,'%Y-%m-%d'),'/',lpad(padding+1,4,0)) INTO Bill_view;

		
	END IF ;
RETURN Bill_view;
END // 
drop function get_bill_no;
select get_bill_no("2023-12-14");
   
/*
3. Create SP to insert line items one by one. Return total amount during each insertion.
*/
   
DELIMITER //
CREATE PROCEDURE insert_med(billid INT, medid INT, quantity INT)
BEGIN

    -- Insert line item
    INSERT INTO Bill_order (Bill_id, Medicine_id, Quantity)
    VALUES (billid ,medid , quantity);

    -- Get total bill amount
    SELECT Bill_id,Medicine_name,(Medicine_price * bb.Quantity) AS Total_price
    FROM Bill_order as bb join Medicine using(Medicine_id) 
    WHERE Bill_id = billid;
END//

drop procedure insert_med;
CALL insert_med(1,2,3);

use Bill;
   
   
   
   
/*
4. Use trigger/SP to reduce stock inventory.
*/
DELIMITER //
CREATE TRIGGER reduce 
    AFTER INSERT ON Bill_order
    FOR EACH ROW 
    BEGIN
      UPDATE s_m
           SET s_m.quantity = s_m.quantity - NEW.Quantity
           WHERE Medicine_id=NEW.Medicine_id;
    END //
    
    DROP TRIGGER reduce;


/*
5.Ceate SP to display top 10 items sold by date/by month. Top 10 by no. of items and monetary value.
*/ 
DELIMITER //
CREATE PROCEDURE t_10(ddate date)
BEGIN
SELECT  m.Medicine_id,m.Medicine_Name,bb.Quantity, (Medicine_price * bb.Quantity) AS Total_price FROM Medicine m 
JOIN
Bill_order AS bb USING(Medicine_id)
JOIN
Bill AS b
USING (Bill_id) WHERE b.Bill_date = ddate 
ORDER BY Total_price DESC LIMIT 10;
END //
DROP PROCEDURE t_10;
CALL t_10('2023-12-01');



/*
6. Create SP to display items nearing expiry (less than 5 months, 4 months, 3....so on)
*/
DELIMITER //
CREATE PROCEDURE expiry(ddate date )
BEGIN
DECLARE my_month INT ;
SET my_month =  MONTH(ddate) ;
SELECT * FROM Medicine
	WHERE 
    -- m.Medicine_Expiry < (current_date() - INTERVAL 30 DAY);
     -- Medicine_Expiry between curdate() AND curdate()-30;
     Medicine_Expiry < ADDDATE(NOW(), INTERVAL 30 DAY) 
UNION
     SELECT * FROM Medicine
	WHERE 
     Medicine_Expiry < ADDDATE(NOW(), INTERVAL 500 DAY)
	UNION
     SELECT * FROM Medicine
	WHERE 
     Medicine_Expiry < ADDDATE(NOW(), INTERVAL 1500 DAY);
     
END//

CALL expiry;

  /* or */

DELIMITER //
CREATE PROCEDURE expp()
BEGIN
SELECT Medicine_id,Medicine_Name,s.Store_name AS available_in_store ,
CASE WHEN CONCAT(timestampdiff(month,current_date(),Medicine_Expiry),'  Months') <= 0 THEN 'EXPIRED'
ELSE CONCAT(timestampdiff(month,current_date(),Medicine_Expiry),'  Months')	END
AS Expiring_in_Month FROM Medicine
JOIN
s_m USING(Medicine_id) 
JOIN
Store AS s USING(Store_id);
END //
DROP PROCEDURE expp;
CALL expp;
/*
7. Create SP/view to display items nearing out of stock. (less than 10).
*/
DELIMITER //
CREATE PROCEDURE stock_out()
BEGIN
SELECT m.Medicine_id,m.Medicine_name,sm.quantity FROM S_m AS sm
JOIN
Medicine AS m USING(Medicine_id)
WHERE quantity <10; 
END//

DROP PROCEDURE stock_out;

CALL stock_out;
