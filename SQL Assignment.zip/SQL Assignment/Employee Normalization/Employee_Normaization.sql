
/*Original Table*/
create table Emp(emp_no int , First_Name varchar(25) , Last_Name varchar(25), Date_of_birth DATE , Date_of_joining
date , Job_Designation varchar(25) , Salary int , ManagerId int , Dept_name varchar(25) , Dept_no int);


/*Normalize tables*/

 /* Employee table*/
 create table Emp(emp_no int PRIMARY KEY , First_name varchar(25) , Last_Name varchar(25) ,Date_of_birth date  ,
 Date_of_joining date ,Job_designation varchar(25) , salary int);
 
/* Department table*/
create table Dept(dept_No INT PRIMARY KEY , Dept_Name varchar(25) , emp_no int ,
FOREIGN KEY(emp_no) REFERENCES Emp(emp_no));

/*Manager table*/
create table Manager(m_id int PRIMARY KEY , dept_no int , FOREIGN KEY(dept_no) REFERENCES Dept(Dept_no),emp_no int 
,FOREIGN KEY(emp_no) REFERENCES Emp(emp_no));	

/*Employee Manager Department*/
create table emd(emp_no int, FOREIGN KEY (emp_no) REFERENCES emp(emp_no),dept_no int, FOREIGN KEY(dept_no) REFERENCES Dept(dept_no),
				m_id int ,FOREIGN KEY(m_id) REFERENCEs Manager(m_id));
 
/*OWN example*/
/* lets say we have one employee table with emp no,name,position and salary */
 
create table employee1(eno int primary key, ename varchar(20), eposition varchar(20),esal int);
insert into employee1 values(1,"gaurav","intern",10000),
							(2,"Sumit","intern,Developer",15000);

 /* lets assume that the company for which eployee works is small and multiple employee work for multiple job positions
	which creates an anomaly,
	to make above table into 1NF we will simply repeate insertion of Employee "Sumit" again for his second job position*/
    
    insert into employee1 values(1,"gaurav","intern",10000),
								(2,"Sumit","intern,Developer",15000),
								(3,"Sumit","Developer",15000),
                                (4,"Sangram","CEO",20000),
                                (3,"Sangram","CTO",20000);

                                
/* Now if we want to add one coloumn to our employee table, lets say rating then If we delete no 1 record his rating will be lost 
this creates and deletion anomoly.
To solve this we'll simple create 2 tables
It'll make our table in 2NF */

create table employee1(eno int primary key, ename varchar(20), eposition varchar(20),esal int);
create table rating(eno int, rating varchar(20) , FOREIGN KEY (eno)  
REFERENCES employee1(en));

 insert into employee1 values(1,"gaurav","intern",10000),
								(2,"Sumit","intern,Developer",15000),
								(3,"Sumit","Developer",15000),
                                (4,"Sangram","CEO",20000),
                                (5,"Sangram","CTO",20000);
                                
insert into rating values(1,"***"),(2,"****"),(1,"****"),(1,"*****"),(1,"*****");

/* Now if we want to add one more coloumn Skill level where 1 to 3 stars will give experience level which will be decided on no of stars in rating,
1 to 3 = beginner, 4 = Intermediate , 5 = Expert
now here if one employee Rank up in oe star from 3 to 4 then we need to change his rating as well as experiance level which s transitive dependancy 
to resolve it and make it into 3NF columns like  */

create table rating_skill(exp varchar(20),rating varchar(20), foreign key (rating) references rating(rating));

insert into rating_skill values("Expert","*****"),
								("Intermediate","****"),
                                ("Beginner","***"),
                                ("Beginner","**"),
                                ("Beginner","*");