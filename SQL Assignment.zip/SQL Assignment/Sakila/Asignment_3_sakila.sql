/*
1.display the first and last names, as well as the address, of each staff member. Use the tables staff and address:
*/

SELECT s.first_name, s.last_name,a.address FROM staff AS s
JOIN
address AS a ON s.address_id = a.address_id;


/*
2. Display the total amount rung up by each staff member in August of 2005. Use tables staff and payment
*/
 SELECT s.first_name,COUNT(p.amount) AS TOTAL_PAYOUT FROM payment AS p 
 JOIN staff AS s ON p.staff_id = s.staff_id 
 WHERE p.payment_date BETWEEN "2005-08-01" AND "2005-08-31" group by s.first_name; 
 
 /*
 3. List each film and the number of actors who are listed for that film. Use tables film_actor and film.
 */
 
 SELECT f.title, count(actor_id) AS Total_Actors FROM film AS f 
 JOIN film_actor AS fa ON f.film_id=fa.film_id GROUP BY f.title; 

/*
4. How many copies of the film DANCING FEVER exist in the inventory system
*/

SELECT count(f.film_id) FROM film AS f 
JOIN inventory AS i ON f.film_id = i.film_id
WHERE f.title = "DANCING FEVER"  GROUP BY f.film_id;  

/*
5. Using the tables payment and customer, list the total paid by each customer. List the customers alphabetically by last name:
*/

SELECT concat(c.first_name," ",c.last_name) AS Customer_name,count(p.amount) AS total_amount 
FROM payment AS p 
JOIN customer AS c ON p.customer_id = c.customer_id group by first_name ORDER BY last_name ASC;
		
/*
6. Use subqueries to display all actors who appear in the film DANCING FEVER
*/

SELECT concat(first_name," ",last_name) as Actor_name FROM actor where actor_id in
(SELECT actor_id from film_actor where film_id in
(SELECT film_id FROM film where title = "DANCING FEVER"));

/*
7.Which actor last names appear more than once?
*/
SELECT concat(first_name," ",last_name) as Actor_Name 
FROM actor group by last_name having count(last_name)>1;

/*
8.Which actor has appeared in the most films?
*/

SELECT concat(first_name," ",last_name) AS Actor_Name,count(fa.actor_id) AS ca 
FROM actor a 
JOIN film_actor AS fa ON a.actor_id=fa.actor_id GROUP BY fa.actor_id ORDER BY ca DESC LIMIT 1;

/*
9. Is ‘Academy Dinosaur’ available for rent from Store 1?
*/

SELECT f.title AS Film_Name,s.store_id FROM film AS f 
JOIN inventory  AS i ON f.film_id= i.film_id 
JOIN store as s ON i.store_id=s.store_id 
WHERE f.title = "Academy Dinosaur" and s.store_id=1 group by f.title;

/*
10 Insert a record to represent Mary Smith renting ‘Academy Dinosaur’ from Mike Hillyer at Store 1 today.
*/

/*
11. When is ‘Academy Dinosaur’ due?
rental\inventory\film
*/

SELECT f.title,max(return_date) AS Due  FROM film AS f
JOIN 
inventory AS i ON f.film_id=i.film_id 
JOIN
rental AS r ON r.inventory_id=i.inventory_id
where f.title="Academy Dinosaur";

/*OR*/

SELECT f.title,(rental_date-return_date) AS due  FROM film AS f
JOIN 
inventory AS i ON f.film_id=i.film_id 
JOIN
rental AS r ON r.inventory_id=i.inventory_id
where f.title="Academy Dinosaur" and (rental_date-return_date) > current_date();

select * from film where title = "Academy Dinosaur";

/*
12. What is that average running time of all the films in the sakila DB?
*/
SELECT AVG(length) FROM film;

/*
13. What is the average running time of films by category?
*/
SELECT c.name,avg(length) FROM film AS F 
JOIN
film_category AS fa ON f.film_id=fa.film_id 
JOIN
category AS c ON fa.category_id=c.category_id group by c.name;  

/*
14. Display the most frequently rented movies in descending order
flim,rent,inventory
*/

SELECT f.title,count(f.title) as z FROM film AS f 
JOIN inventory  as i ON  f.film_id = i.film_id 
JOIN
rental AS r ON  i.inventory_id = r.inventory_id group by (f.title) ORDER BY z DESC;  




/*
15. Sales have been lagging among young families, and you wish to target all family movies for a promotion.
Identify all movies categorized as family films

*/
SELECT f.title,c.name FROM film AS f 
JOIN
film_category AS fc ON f.film_id=fc.film_id 
JOIN
category AS c ON fc.category_id=c.category_id 
WHERE c.name LIKE "%fam%";

/*
16 In your new role as an executive, you would like to have an easy way of viewing the Top five genres by gross revenue. Use the 
from the problem above to create a view. If you haven’t solved the above question you can substitute another query to create a view.
*/

create view top_5_genre as 
	SELECT c.name as 'Genere', sum(p.amount) as 'Gross Revenue'
	from category as c
	join
    film_category as fc on fc.category_id = c.category_id
	join
    inventory as i on i.film_id = fc.film_id
	join
    rental as r on r.inventory_id = i.inventory_id
	join
    payment as p on p.rental_id = r.rental_id
	group by c.name order by sum(p.amount) desc limit 5;
    
    SELECT * FROM top_5_genre;
    use sakila;
   
   
   delimiter //
    create function dateConvet(uu_date int)
    returns varchar(20)
    DETERMINISTIC
    begin
    DECLARE u_date INT  DEFAULT 0;
    SELECT uu_date INTO u_date;
    if LENGTH(u_date) <> 8 then
    return NULL;
    End if ;
	return concat(substring(u_date,1,4),"-",monthname(u_date),"-",substring(u_date,7,8));
    end//
	delimiter //
    
	 select dateConvet(20230229);
drop function dateConvet;
dele