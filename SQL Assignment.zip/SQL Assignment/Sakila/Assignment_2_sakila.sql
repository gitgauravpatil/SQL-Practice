/*1. Return the full names (first and last) and address of customers with “SON” in their last name, ordered by their first name.
*/

SELECT concat(first_name," ",last_name) AS full_name 
FROM customer AS c JOIN address AS a 
ON c.address_id=a.address_id WHERE last_name LIKE "%son%" ORDER BY last_name ASC;

/*
2. Find all the addresses where the second address is not empty (i.e., contains some text), and return these second addresses sorted.
*/
SELECT * FROM address 
WHERE address2 <> "" AND address IS NOT NULL ORDER BY address2 ASC;

/*
3. In how many film categories is the average difference between the film replacement cost and the rental rate larger than 17?
*/
SELECT count(category_id) FROM category 
WHERE category_id IN 
(SELECT category_id FROM film AS f JOIN film_category AS fc ON  f.film_id = fc.film_id GROUP BY category_id 
HAVING AVG(replacement_cost-rental_rate)>17);

/*
4. Find the address district(s) name(s) such that the minimal postal code in the district(s) is maximal over all the districts.
 Make sure your query ignores empty postal codes and district names.
*/

SELECT postal_code,district,address FROM address 
WHERE postal_code IN
(SELECT max(postal_code) FROM address WHERE postal_code IN
(SELECT min(postal_code) FROM address WHERE district IS NOT NULL AND postal_code IS NOT NULL GROUP BY district));

/*5. List all the actor names with their film names.
 */
SELECT first_name, title FROM film_actor AS fa 
JOIN actor AS a ON fa.actor_id=a.actor_id
JOIN film AS fl ON fa.film_id=fl.film_id ;

/*
6.Return the first and last names of actors who played in a 
film involving a “Crocodile” and a “Shark”, along with the release year of the movie, sorted by the actors’ last names.
*/
SELECT first_name, last_name,DESCRIPTION FROM actor AS a 
JOIN film_actor AS fa ON a.actor_id = fa.actor_id 
JOIN film AS f ON f.film_id = fa.film_id HAVING DESCRIPTION LIKE "% shark%" AND DESCRIPTION LIKE "%Crocodile%"; 

/*
7.How many films involve a “Crocodile” and a “Shark”?
*/

SELECT count(title)FROM film 
WHERE DESCRIPTION LIKE"%shark%" AND DESCRIPTION LIKE "%Crocodile%";


/*8. Find the names (first and last) of all the actors and custumers whose first name is the same as the first name of the actor with ID 8.
 Do not return the actor with ID 8 himself. Note that you cannot use the name of the actor with ID 8 as a constant (only the ID)
 There is more than one way to solve this question, but you need to provide only one solution.
*/
SELECT first_name,last_name FROM customer
WHERE first_name = (SELECT first_name FROM actor WHERE actor_id = 8)
UNION ALL
SELECT first_name,last_name
FROM actor
WHERE actor_id <> 8 AND first_name = (SELECT first_name FROM actor WHERE actor_id = 8);


/*
9. Find all the film categories in which there are between 55 and 65 films.
 Return the names of these categories and the number of films per category, sorted by the number of films.
*/

SELECT NAME, count(film_id) AS total_film FROM film_category AS fc 
JOIN category AS c ON fc.category_id = c.category_id 
GROUP BY NAME HAVING total_film > 54 AND total_film <66 ORDER BY total_film;
